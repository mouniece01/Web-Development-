import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InternshipService } from 'src/Services/internship.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  users!: any[];
  status!: number;
  errorMsg!: string;
  msg!: string;
  showDiv: boolean = false;
  name!: string;
  loginRole!: number;
  rolename!: string;
  showLoginForm = true;
  showResetPasswordForm = false;
  id: any;
  showDivinPwdfrm:any;

  constructor(private service: InternshipService, private router: Router, private route: ActivatedRoute) {

    this.service.UsersDetails().subscribe({
      next: (successMsg: any) => {
        this.users = successMsg
        console.log(this.users)
      },
      error:
        responseLoginError => {
          this.errorMsg = responseLoginError;
        }
    })

  }

  ngOnInit(): void {

  }
  submitLoginForm(form: NgForm) {

    for (let index = 0; index < this.users.length; index++) {
      if (this.users[index].EmailId == form.value.email && this.users[index].UserPassword == form.value.password) {
        this.msg = "Login Successfull!!"
        break;
      }
      else {
        this.msg = "Try again with valid credentials.";
      }
    }
    this.showDiv = true;


  }

  resetPassword(form: NgForm) {
    this.id=null;
    console.log(form.value.password + "abc"+form.value.confirmPassword)
    for (let index = 0; index < this.users.length; index++) {
      if (this.users[index].EmailId == form.value.email &&
        this.users[index].ContactNumber == parseInt(form.value.contactNumber) &&
        this.users[index].DateOfBirth == form.value.dob) {
        if (form.value.password == form.value.confirmPassword){
          this.id = this.users[index].id;
          console.log(this.id)
          break;
        }
        else if (form.value.password != form.value.confirmPassword) {
          this.msg = "Password and Confirm Password are not matching"
          this.showDivinPwdfrm = true
        }
        break;
      }
      else {
        this.msg = "Enter Valid Credentials!!!"
        this.showDivinPwdfrm = true
      }
    }
    if (this.id != null) {
      console.log(this.id+"qbcc")
      this.service.forgotPassword(this.id, form.value.password).subscribe({
        next: (successMsg: any) => {
          console.log(successMsg)
          this.msg = "Password Changed Successfully!!"
          this.showDivinPwdfrm=true
        },
        error: (errorMsg: any) => {
          console.log(errorMsg);
        }
      })
    }


  }

  showloginForm(){
    this.showLoginForm = true;
    this.showResetPasswordForm = false;
    this.showDivinPwdfrm = false;
    this.showDiv=false
  }

  forgotPasswordForm() {
    this.showLoginForm = false;
    this.showResetPasswordForm = true;
    this.showDivinPwdfrm = false;
  }

}
