import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class InternshipService {

  constructor(private http: HttpClient) { }

  UsersDetails(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:44393/users')
  }

  validateCredentials(email: any, password: any, loginRole: number): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:44393/users')
  }

  forgotPassword(id: number, password: any) {
    return this.http.patch('http://localhost:44393/users/' + id, { UserPassword: password })
  }
}
